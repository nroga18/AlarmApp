package ge.nrogava.alarmapp.main

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager.IMPORTANCE_HIGH
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import ge.nrogava.alarmapp.R

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        Log.d(TAG, "message received")
        context?.let {
            if (intent?.action == ALARM_ACTION_NAME) {
                var notificationManager = NotificationManagerCompat.from(context)

                val notificationClickPendingIntent = PendingIntent.getActivity(
                    context,
                    0,
                    Intent(context, MainActivity::class.java),
                    0
                )
                val buttonClickIntent = PendingIntent.getActivity(
                    context,
                    0,
                    Intent(context, MainActivity::class.java),
                    0
                )

                val receiverButtonClick = PendingIntent.getBroadcast(
                    context,
                    0,
                    Intent("ge.nrogava.alarmapp.main.NOTIFICATION_CLICK").apply {
                        `package` = context.packageName
                    },
                    0
                )

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    createChannel(notificationManager)
                }

                var notification = NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(R.mipmap.ic_launcher_round)
                    .setContentTitle(ALARM_Message)
                    .setContentText(ALARM_SET_ON )
                    .setContentIntent(notificationClickPendingIntent)
                    .addAction(R.mipmap.ic_launcher, "Cancel", buttonClickIntent)
                    .addAction(R.mipmap.ic_launcher, "Snooze", receiverButtonClick)
                    .build()

                notificationManager.notify(NOTIFICATION_ID, notification)
            }else{
                Toast.makeText(context, "Notification clicked", Toast.LENGTH_SHORT).show()
            }

        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createChannel(notificationManager: NotificationManagerCompat) {
        var notificationChannel = NotificationChannel(CHANNEL_ID, "channel_name", IMPORTANCE_HIGH)
        notificationManager.createNotificationChannel(notificationChannel)
    }

    companion object {
        const val TAG = "ALARM_REVIECER"
        const val ALARM_ACTION_NAME = "ge.nrogava.alarmapp.main.ALARM_ACTION"

        const val NOTIFICATION_ID = 22
        const val CHANNEL_ID = "ge.nrogava.alarmapp.main.CHANNEL_1"
        const val ALARM_Message = "Alarm message!"
        const val ALARM_SET_ON = "Alarm set on "

    }
}