package ge.nrogava.alarmapp.main

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class MyBroadcastReceiver : BroadcastReceiver(){
    override fun onReceive(context: Context?, intent: Intent?) {
        val action = intent?.action

        if (action.equals("Delete")){
            val ussreID = intent?.getStringExtra("UserID")
            Toast.makeText(context,"Deleted ID: $ussreID",Toast.LENGTH_SHORT).show()
        }

        if (action.equals("Update")){
            val ussreID = intent?.getStringExtra("UserID")
            val name = intent?.getStringExtra("Name")
            Toast.makeText(context,"Update : $name",Toast.LENGTH_SHORT).show()
        }
    }
}