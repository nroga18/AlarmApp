package ge.nrogava.alarmapp.main

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.widget.Button
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.RecyclerView
import ge.nrogava.alarmapp.R
import ge.nrogava.alarmapp.data.entity.Alarm
import java.text.SimpleDateFormat
import java.util.Calendar.*


class MainActivity : AppCompatActivity(), MainInteractor.AlarmListListener, IMainView {
    lateinit var btn_add: Button
    lateinit var btn_notif: Button
    lateinit var txt_light: TextView
    lateinit var alarmList: RecyclerView
    private lateinit var presenter: MainPresenter
    private var adapter = AlarmAdapter(this)

    lateinit var notificationManager: NotificationManager
    lateinit var notificationChannel: NotificationChannel
    lateinit var builder: Notification.Builder
    private val channelId = "ge.nrogava.alarmapp.main"
    private val description = "test notifiaction"



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initView()

        presenter = MainPresenter(this)
        presenter.getAlarmList()

        setTheme()


    }
    private fun setTheme(){
        when (this?.resources?.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
            Configuration.UI_MODE_NIGHT_YES -> {
                txt_light.text = LIGHT
                btn_add.setBackgroundResource(R.drawable.white_add)
            }
            Configuration.UI_MODE_NIGHT_NO -> {
                txt_light.text = DARK
                btn_add.setBackgroundResource(R.drawable.add)
            }
            Configuration.UI_MODE_NIGHT_UNDEFINED -> {
                txt_light.text = DARK
                btn_add.setBackgroundResource(R.drawable.add)
            }
        }
    }



    fun initView() {
        btn_add = findViewById(R.id.btn_add)
        btn_notif = findViewById(R.id.btn_notification)
        txt_light = findViewById(R.id.txt_light)
        alarmList = findViewById(R.id.alarm_list)
        alarmList.adapter = adapter

        btn_add.setOnClickListener {
            TimePickerFragment(presenter, this).show(supportFragmentManager, "timePicker")
        }
        txt_light.setOnClickListener {
            changeTheme()
        }

        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        test()
        /*
        btn_notif.setOnClickListener {
            startAlarm()

        }

         */
    }
    private fun test() {
        val channelId = "My_Channel_ID"
        createNotificationChannel(channelId)

        // Create an explicit intent for an activity in this app
        val intent = Intent(this,MainActivity::class.java)
        intent.apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(this,0,intent,0)


        val deleteIntent = Intent(this,MyBroadcastReceiver::class.java)
        deleteIntent.apply {
            action = "Delete"
            putExtra("UserID","100")
        }
        val deletePendingIntent = PendingIntent.getBroadcast(this,0,deleteIntent,0)


        val updateIntent = Intent(this,MyBroadcastReceiver::class.java)
        updateIntent .apply {
            action = "Update"
            putExtra("UserID","100")
            putExtra("Name","Jones")
        }
        val updatePendingIntent = PendingIntent.getBroadcast(this,0,updateIntent ,0)


        btn_notif.setOnClickListener{
            val notificationBuilder = NotificationCompat.Builder(this,channelId)
                .setSmallIcon(R.mipmap.ic_launcher_round)
                .setContentTitle("Title: API LEVEL " + Build.VERSION.SDK_INT)
                .setContentText("Delete or update user.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .addAction(R.mipmap.ic_launcher,"Delete User",deletePendingIntent)
                .addAction(R.mipmap.ic_launcher,"Update User",updatePendingIntent)

            with(NotificationManagerCompat.from(this)){
                notify(1, notificationBuilder.build())
            }
        }
    }

    private fun createNotificationChannel(channelId:String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val name = "My Channel"
            val channelDescription = "Channel Description"
            val importance = NotificationManager.IMPORTANCE_DEFAULT

            val channel = NotificationChannel(channelId,name,importance)
            channel.apply {
                description = channelDescription
            }

            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
    private fun startAlarm() {
        var pi = PendingIntent.getBroadcast(
            this,
            ALARM_REQUEST_CODE,
            Intent(AlarmReceiver.ALARM_ACTION_NAME).apply {
                `package` = packageName
            },
            0
        )
        var alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 1000, pi)
        }

    }

    private fun changeTheme(){
        val txt = txt_light.text

        if (txt == DARK) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else if (txt == LIGHT) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }
    override fun onAlarmClicked(alarm: Alarm): Boolean {
        DialogDemoFragment(presenter, alarm.id).show(supportFragmentManager, DialogDemoFragment.FRAGMENT_TAG)
        return true
    }

    override fun onAlarmSwitchClicked(alarm: Alarm) {
        presenter.updateAlarm(alarm.id, alarm.Time, !alarm.Active)
    }

    override fun setList(result: List<Alarm>) {
        adapter.list = result
        adapter.notifyDataSetChanged()
    }
    class TimePickerFragment(val presenter: MainPresenter, val mainActivity: MainActivity) : DialogFragment(), TimePickerDialog.OnTimeSetListener {

        override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
            val c = getInstance()
            val hour = c.get(HOUR_OF_DAY)
            val minute = c.get(MINUTE)

            return TimePickerDialog(
                activity,
                this,
                hour,
                minute,
                DateFormat.is24HourFormat(activity)
            )
        }

        override fun onTimeSet(view: TimePicker, hourOfDay: Int, minute: Int) {
            val cal = getInstance()
            val c = getInstance()
            cal.set(HOUR_OF_DAY, hourOfDay)
            cal.set(MINUTE, minute)
            if(cal.time >= c.time){
                presenter.addNewAlarm(Alarm(SimpleDateFormat("HH:mm").format(cal.time), true))
            }else{
                Toast.makeText(mainActivity, "Invalid Time", Toast.LENGTH_LONG).show();
            }
        }
    }
    class DialogDemoFragment(val presenter: MainPresenter,val alarmid: Int) : DialogFragment() {
        override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {


            var dialog = androidx.appcompat.app.AlertDialog.Builder(requireContext())
           .setMessage(ALERT_MESSAGE)
                .setCancelable(false)
                .setPositiveButton(YES_BTN) { dialog, which ->
                presenter.deleteAlarm(alarmid)
            }
                .setNegativeButton(NO_BTN) { dialog, which ->

                }
                .create()
            return dialog
        }

        companion object {
            const val FRAGMENT_TAG = "dialogTag"
            val ALERT_MESSAGE = "Are you sure you want to delete this item"
        }
    }

    companion object {

        val YES_BTN = "YES"
        val NO_BTN = "NO"
        val DARK = "Switch to dark"
        val LIGHT = "Switch to light"
        val WHITE = "white"
        val BLACK = "black"

        const val ALARM_REQUEST_CODE = 200


    }
}